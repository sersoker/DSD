/home/mangox/jdk1.6.0_30/bin/java -cp . -Djava.rmi.server.codebase=file:/home/mangox/simple/ -Djava.rmi.server.hostname=localhost -Djava.security.policy=server.policy Ejemplo
