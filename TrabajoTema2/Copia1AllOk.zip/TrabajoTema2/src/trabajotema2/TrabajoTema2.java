package trabajotema2;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

public class TrabajoTema2 implements java.io.Serializable{
    public static void main(String[] args) throws IOException, ClassNotFoundException, NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        
    //Creamos el loader
    ClassLoader classLoader = TrabajoTema2.class.getClassLoader();

    try {
        //Hacemos el load de la clase
        Class aClass = classLoader.loadClass("ClaseASerializar");
        //Obtenemos un listado de los metodos de la clase
        Method[] methods = aClass.getMethods();
        //Los mostramos por pantalla
        for (Method item : methods) {
            System.out.println("Metodo con nombre: "+item.getName()+" y numero de parametros:"+item.getParameterCount());
        }
        
        //Cargamos el fichero de salida e invocamos a la funcion obtenerRutaCompleta
        FileInputStream fis = new FileInputStream("./src/trabajotema2/fichero.salida");
        ObjectInputStream ois = new ObjectInputStream(fis);
        Object object = (Object) ois.readObject();
        
            String nombre = "obtenerDirecciónClase";
            System.out.println(nombre);
            Method method = aClass.getMethod(nombre,null);
            Object o = method.invoke(object, null);
            String direccion=o.toString();
            //String direccion=o.toString().split(".class")[0];
            System.out.println(direccion);
             nombre = "obtenerNombreClase";
            System.out.println(nombre);
             method = aClass.getMethod(nombre,null);
             o = method.invoke(object, null);
            String nombreClase=o.toString();
            //String direccion=o.toString().split(".class")[0];
            System.out.println(nombreClase);        
            ois.close();

URLClassLoader urlClassLoader = new URLClassLoader(new URL[]{new URL(direccion)});

Class bClass = urlClassLoader.loadClass(nombreClase);
Method[] methods2 = bClass.getMethods();
        for (Method item : methods2) {
            System.out.println("Metodo con nombre: "+item.getName()+" y numero de parametros:"+item.getParameterCount());
        }

Object oo = bClass.newInstance();
Method method1 = bClass.getMethod("computa",String.class);
Object o2 = method1.invoke(oo, "45712353");
System.out.println("Salida de la llamada a funcion Computa:"+o2);


    } catch (ClassNotFoundException e) {
        e.printStackTrace();
    }
 }
}   
